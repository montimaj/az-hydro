"""
Handle various raster operations.
"""

# Author: Dr. Sayantan Majumdar
# Email: sayantan.majumdar@dri.edu

import logging
import os
import shutil
import subprocess
from glob import glob

import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
import rasterio as rio
from fiona import transform
from joblib import Parallel, delayed
from osgeo import gdal
from rasterio.mask import mask
from rasterio.plot import plotting_extent
from shapely.geometry import mapping

from hydrolibs.sysops import az_nodata, makedirs

gdal.PushErrorHandler('CPLQuietErrorHandler')
gdal.UseExceptions()

logger = logging.getLogger(__name__)


def read_raster_as_arr(
        raster_file: str | rio.DatasetReader,
        band: int = 1,
        get_file: bool = True,
        change_dtype: bool = True,
        file_mode: str = 'r'
) -> tuple[np.ndarray, rio.DatasetReader] | np.ndarray:
    """Read a raster band as a numpy array.

    Args:
        raster_file (str or rio.DatasetReader): Input raster file path or rasterio DatasetReader object.
        band (int): Selected band to read (Default 1).
        get_file (bool): Get rasterio DatasetReader object file if set to True.
        change_dtype (bool): Change raster data type to float if True. Also, if a no data value exists, then it is set
                             to np.nan if change_dtype is True.
        file_mode (str): File mode to read raster file. Default is 'r' for read. Set to 'r+' to read and write.

    Returns:
        np.ndarray: Raster numpy array (if, get_file is False).
        tuple (np.ndarray, rio.DatasetReader): A tuple of raster numpy array and rasterio object file (if,
                                               get_file is True and raster_file is a raster file path).
    """
    rasterio_obj = isinstance(raster_file, rio.DatasetReader)
    if not rasterio_obj:
        raster_file = rio.open(raster_file, mode=file_mode)
    else:
        get_file = False
    raster_arr = raster_file.read(band)
    if change_dtype:
        raster_arr = raster_arr.astype(np.float32)
        if raster_file.nodata is not None:
            raster_arr[np.isclose(raster_arr, raster_file.nodata)] = np.nan
    if get_file:
        return raster_arr, raster_file
    return raster_arr


def write_raster(
        raster_data: np.ndarray,
        raster_file: rio.DatasetReader,
        transform_: rio.transform,
        outfile_path: str,
        no_data_value: float,
        ref_file: str | None = None,
        out_crs: str | None = None,
        num_bands: int | None = None
) -> None:
    """Write raster file in GeoTIFF format.

    Args:
        raster_data (np.ndarray): Raster data (numpy array) to be written.
        raster_file (rio.DatasetReader): Original rasterio raster DatasetReader object containing geo-coordinates.
        transform_ (rio.transform): Affine transformation matrix.
        outfile_path (str): Outfile file path.
        no_data_value (float): No data value for raster (default float32 type is considered).
        ref_file (str): Write output raster considering parameters from reference raster file path
        out_crs (str): Output crs.
        num_bands (int or None): Number of bands to write. If None, raster_file.count number of bands will be used.

    Returns:
        None
    """
    if ref_file:
        raster_file = rio.open(ref_file)
        transform_ = raster_file.transform
    crs = raster_file.crs
    if out_crs:
        crs = out_crs
    if num_bands is None:
        num_bands = raster_file.count
    with rio.open(
            outfile_path,
            'w',
            driver='GTiff',
            height=raster_data.shape[0],
            width=raster_data.shape[1],
            dtype=raster_data.dtype,
            crs=crs,
            transform=transform_,
            count=num_bands,
            nodata=no_data_value
    ) as dst:
        dst.write(raster_data, num_bands)


def clamp_and_rewrite_raster(
        raster_file: str,
        min_val: float = 0,
        max_val: float | None = None,
        band_descriptions: list[str] | None = None
) -> None:
    """Clamp raster values to a given range and rewrite the file with updated statistics.

    Reads the raster, clamps pixel values to [min_val, max_val], rewrites the file from scratch
    (discarding stale embedded statistics), and optionally sets band descriptions.

    Args:
        raster_file (str): Path to the raster file.
        min_val (float): Minimum allowed pixel value. Defaults to 0.
        max_val (float or None): Maximum allowed pixel value. If None, no upper clamp is applied.
        band_descriptions (list[str] or None): List of band description strings. If provided, must
            have one entry per band.

    Returns:
        None
    """
    with rio.open(raster_file) as src:
        arr = src.read()
        profile = src.profile.copy()
    arr = np.maximum(arr, min_val)
    if max_val is not None:
        arr = np.minimum(arr, max_val)
    os.remove(raster_file)
    with rio.open(raster_file, 'w', **profile) as dst:
        dst.write(arr)
        if band_descriptions is not None:
            for idx, desc in enumerate(band_descriptions, start=1):
                dst.set_band_description(idx, desc)


def crop_raster(
        input_raster_file: str,
        input_mask_path: str,
        outfile_path: str,
        plot_fig: bool = False,
        plot_title: str = "",
        ext_mask: bool = True,
        multi_poly: bool = False,
) -> None:
    """
    Crop raster data based on given shapefile.

    Args:
        input_raster_file (str): Input raster dataset path.
        input_mask_path (str): Shapefile path.
        outfile_path (str): Output file path (only tiff file).
        plot_fig (bool): If true, then cropped raster data is plotted.
        plot_title (str): Plot title to display.
        ext_mask (bool): Set true to extract raster by mask file.
        multi_poly (bool): Set True if input_mask_file has multiple polygons/features.

    Returns:
        None.
    """

    if multi_poly:
        mask_shp_file = gpd.read_file(input_mask_path)
        raster_arr, raster_file = read_raster_as_arr(input_raster_file)
        geometries = [geom for geom in mask_shp_file.geometry if geom is not None]
        masked_arr, masked_transform = mask(
            raster_file, geometries, crop=False, nodata=np.nan, all_touched=True
        )
        raster_arr = np.squeeze(masked_arr)
        no_data_value = az_nodata()
        raster_arr[np.isnan(raster_arr)] = no_data_value
        write_raster(
            raster_arr, raster_file, transform_=raster_file.transform,
            outfile_path=outfile_path, no_data_value=no_data_value
        )
        raster_file.close()
    else:
        if ext_mask:
            src_raster_file = gdal.Open(input_raster_file)
            src_band = src_raster_file.GetRasterBand(1)
            transform_ = src_raster_file.GetGeoTransform()
            xres, yres = transform_[1], transform_[5]
            no_data = src_band.GetNoDataValue()
            os_sep = input_mask_path.rfind(os.sep)
            if os_sep == -1:
                os_sep = input_mask_path.rfind('/')
            layer_name = input_mask_path[os_sep + 1: input_mask_path.rfind('.')]
            warp_options = gdal.WarpOptions(
                dstNodata=no_data,
                cutlineDSName=input_mask_path,
                cutlineLayer=layer_name,
                cropToCutline=True,
                targetAlignedPixels=True,
                xRes=xres, yRes=yres,
                outputType=gdal.GDT_Float32,
                format='GTiff',
                options=['-overwrite']
            )
            gdal.Warp(outfile_path, input_raster_file, options=warp_options)
        else:
            shape_file = gpd.read_file(input_mask_path)
            shape_file_geom = mapping(shape_file['geometry'][0])
            raster_file = rio.open(input_raster_file)
            raster_crop, raster_transform = mask(raster_file, [shape_file_geom], crop=True)
            shape_extent = plotting_extent(raster_crop[0], raster_transform)
            raster_crop = np.squeeze(raster_crop)
            write_raster(raster_crop, raster_file, transform_=raster_transform, outfile_path=outfile_path,
                         no_data_value=raster_file.nodata)
            if plot_fig:
                fig, ax = plt.subplots(figsize=(10, 8))
                raster_plot = ax.imshow(raster_crop[0], extent=shape_extent)
                ax.set_title(plot_title)
                ax.set_axis_off()
                fig.colorbar(raster_plot)
                plt.show()


def reproject_coords(
        src_crs: str,
        dst_crs: str,
        coords: tuple[tuple[float, float], ...]
) -> list[tuple[float, float]]:
    """Reproject coordinates. Copied from https://bit.ly/3mBtowB.

    Author: user2856 (StackExchange user).

    Args:
        src_crs (str): Source CRS.
        dst_crs (str): Destination CRS.
        coords (tuple( tuple(float, float), ...): Coordinates as a tuple of long, lat pairs as tuples.

    Returns:
        list (tuple (float, float)): Transformed coordinates as a list of long, lat pairs as tuples.
    """
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    xs, ys = transform.transform(src_crs, dst_crs, xs, ys)
    return [(x, y) for x, y in zip(xs, ys)]


def get_raster_extent(
        input_raster: str | rio.DatasetReader,
        new_crs: str | None = None
) -> tuple[float, float, float, float]:
    """Get raster extents using rasterio.

    Args:
        input_raster (str or rio.DatasetReader): Input raster file path or rasterio DatasetReader object.
        new_crs (str): Specify a new crs to convert original extents.

    Returns:
        tuple (float, float, float, float): A tuple containing raster extents as (left, bottom, right, top).
    """
    is_rio_obj = isinstance(input_raster, rio.DatasetReader)
    if not is_rio_obj:
        input_raster = rio.open(input_raster)
    raster_extent = input_raster.bounds
    left = raster_extent.left
    bottom = raster_extent.bottom
    right = raster_extent.right
    top = raster_extent.top
    if new_crs:
        raster_crs = input_raster.crs.to_string()
        if raster_crs != new_crs:
            new_coords = reproject_coords(
                raster_crs,
                new_crs,
                ((left, bottom), (right, top))
            )
            left, bottom = new_coords[0]
            right, top = new_coords[1]
    return left, bottom, right, top


def reproject_raster_gdal(
        input_raster_file: str,
        outfile_path: str | None = None,
        resampling_factor: float | None = 1,
        resampling_func: str = 'near',
        downsampling: bool = True,
        from_raster: str | rio.DatasetReader | None = None,
        dst_xres: float | None = None,
        dst_yres: float | None = None,
        output_dtype: str = 'float32',
        src_band_dict: dict[str, tuple[int, str, str]] | None = None,
        dst_raster_dir: str | None = None
) -> None:
    """Reproject raster using GDALWarp Python API.

    Args:
        input_raster_file (str): Input raster file. This should follow Tile_<tile_number>_<year>.tif naming convention
                                 if src_band_dict is specified and outfile_path is None. If src_band_dict is
                                 specified and outfile_path is not None, i.e., input_raster_file is a multi-band
                                 mosaicked raster, then the file name should follow <file_name>_<year>.tif.
        outfile_path (str): Output file path. Set to None if src_band_dict is used.
        resampling_factor (float or None): Resampling factor (default 1).
        resampling_func (str): Resampling function. Valid names include 'near', 'bilinear', 'cubic', 'cubicspline',
                               'lanczos', 'sum', 'average', 'mode', 'max', 'min', 'med', 'q1', 'q3'.
        downsampling (bool): Downsample raster (default True).
        from_raster (str or rio.DatasetReader or None): Reproject input raster considering another raster
                                                        (either raster path or rasterio object).
        dst_xres (float or None): Target xres in input_raster_file units. Set resampling_factor to None.
        dst_yres (float or None): Target yres in input_raster_file units. Set resampling factor to None.
        output_dtype (str):  Output data type. Valid data types include 'byte', 'int16', 'int32', 'float32'.
        src_band_dict (dict (str, tuple (int, str, str)) or None : A dictionary of source band names (as keys) and a
                                                                   tuple of band number (one indexing),
                                                                   band-specific resampling_func, and output_dtype.
                                                                   By default, this is set to None. If not None, then
                                                                   the number of key, value pairs should match the
                                                                   number of bands in input_raster_file.
        dst_raster_dir (str): If src_band_dict is used, the dst_raster_dir must be specified to
                              write all the output tiles or rasters as TIF files.

    Returns:
        None
    """

    try:
        src_raster_file = rio.open(input_raster_file)
        rfile = src_raster_file
        if from_raster:
            if isinstance(from_raster, str):
                rfile = rio.open(from_raster)
            else:
                rfile = from_raster
            resampling_factor = 1
        xres, yres = rfile.res
        extent = get_raster_extent(rfile)
        dst_proj = rfile.crs.to_string()
        no_data = src_raster_file.nodata
        if dst_xres and dst_yres:
            xres, yres = dst_xres, dst_yres
        elif resampling_factor:
            if not downsampling:
                resampling_factor = 1 / resampling_factor
            xres, yres = xres * resampling_factor, yres * resampling_factor
        resampling_dict = {
            'near': gdal.GRA_NearestNeighbour, 'bilinear': gdal.GRA_Bilinear, 'cubic': gdal.GRA_Cubic,
            'cubicspline': gdal.GRA_CubicSpline, 'lanczos': gdal.GRA_Lanczos,  'sum': gdal.GRA_Sum,
            'average': gdal.GRA_Average, 'mode': gdal.GRA_Mode, 'max': gdal.GRA_Max,
            'min': gdal.GRA_Min, 'med': gdal.GRA_Med, 'q1': gdal.GRA_Q1, 'q3': gdal.GRA_Q3,
        }
        output_dtype_dict = {
            'byte': gdal.GDT_Byte,
            'int16': gdal.GDT_Int16,
            'int32': gdal.GDT_Int32,
            'float32': gdal.GDT_Float32
        }
        gdal.UseExceptions()
        gdal.PushErrorHandler('CPLQuietErrorHandler')
        if src_band_dict is None:
            warp_options = gdal.WarpOptions(
                outputBounds=extent,
                dstNodata=no_data,
                dstSRS=dst_proj,
                resampleAlg=resampling_dict[resampling_func],
                xRes=xres, yRes=yres,
                outputType=output_dtype_dict[output_dtype],
                format='GTiff',
                options=['-overwrite']
            )
            gdal.Warp(outfile_path, input_raster_file, options=warp_options)
        else:
            year = input_raster_file[input_raster_file.rfind('_') + 1: input_raster_file.rfind('.')]
            tile_num = ''
            dst_raster_dir_year = f'{dst_raster_dir}{year}/'
            makedirs(dst_raster_dir_year)
            use_tile_format = outfile_path is None
            if use_tile_format:
                tile_num = input_raster_file[input_raster_file.rfind('Tile'): input_raster_file.find(year) - 1]
            output_bands = []
            for band_name in src_band_dict.keys():
                band_num, resampling_func, output_dtype = src_band_dict[band_name]
                if use_tile_format:
                    outband_path = f'{dst_raster_dir_year}{tile_num}_B{band_num}.tif'
                else:
                    outband_path = f'{dst_raster_dir_year}B{band_num}.tif'
                warp_options = gdal.WarpOptions(
                    srcBands=[band_num],
                    dstBands=[1],
                    outputBounds=extent,
                    dstNodata=no_data,
                    dstSRS=dst_proj,
                    resampleAlg=resampling_dict[resampling_func],
                    xRes=xres, yRes=yres,
                    outputType=output_dtype_dict[output_dtype],
                    format='GTiff',
                    options=['-overwrite']
                )
                gdal.Warp(outband_path, input_raster_file, options=warp_options)
                output_bands.append(outband_path)
            if use_tile_format:
                outfile_path = f'{dst_raster_dir}{tile_num}_{year}.tif'
            gdal_merge_path = shutil.which('gdal_merge.py')
            if gdal_merge_path is None:
                raise FileNotFoundError('gdal_merge.py not found on PATH')
            subprocess.call(
                [gdal_merge_path, '-separate'] + output_bands + ['-o', outfile_path],
                stdout=subprocess.DEVNULL
            )
    except Exception as e:
        logger.error(f'Error occurred while resampling {input_raster_file}', exc_info=e)


def crop_rasters(
        input_raster_dir: str,
        input_mask_file: str,
        outdir: str,
        pattern: str = '*.tif',
        ext_mask: bool = True,
        multi_poly: bool = False,
        verbose: bool = False
) -> None:
    """
    Crop multiple rasters in a directory.

    Args:
    input_raster_dir (str): Directory containing raster files which are named as *_<Year>.*
    input_mask_file (str): Mask file (shapefile) used for cropping.
    outdir (str): Output directory for storing masked rasters.
    pattern (str): Raster extension.
    ext_mask (str): Set False to extract by geometry only.
    multi_poly (bool): Set True if input_mask_file has multiple polygons/features.
    verbose (bool): Set True to print system call info.

    Returns:
        None.
    """

    Parallel(n_jobs=-1)(
        delayed(parallel_crop_rasters)(
            raster_file, input_mask_file,
            outdir, ext_mask,
            multi_poly, verbose
        ) for raster_file in glob(os.path.join(input_raster_dir, pattern))
    )


def parallel_crop_rasters(
        input_raster_file,
        input_mask_file,
        outdir, ext_mask=True,
        multi_poly=False, verbose=False
):
    """
    Parallely crop rasters, should be called from #crop_rasters(...)
    :param input_raster_file: Input raster file
    :param input_mask_file: Mask file (shapefile) used for cropping
    :param outdir: Output directory for storing masked rasters
    :param ext_mask: Set False to extract by geometry only
    :param multi_poly: Set True if input_mask_file has multiple polygons/features
    :param verbose: Set True to print system call info
    :return: None
    """

    out_raster = outdir + input_raster_file[input_raster_file.rfind(os.sep) + 1:]
    if verbose:
        logger.info(f'Cropping {input_raster_file} ...')
    crop_raster(
        input_raster_file, input_mask_file,
        out_raster, ext_mask=ext_mask,
        multi_poly=multi_poly
    )

def get_xy_grids_from_raster(
        input_raster_file: str
) -> tuple[np.array, np.array]:
    """Get longitude (x) and latitude (y) grids from a raster file.

    Args:
        input_raster_file (str): Input raster file path.

    Returns:
        tuple (np.array, np.array): A tuple of longitude (x) and latitude (y) as numpy arrays.
    """

    raster_file = rio.open(input_raster_file)
    transform_ = raster_file.transform
    xres, yres = transform_[1], transform_[5]
    cols, rows = raster_file.width, raster_file.height
    lon_min, lat_max = transform_[0], transform_[3]
    lon_max, lat_min = lon_min + (cols * xres), lat_max + (rows * yres)
    lon_vals = np.linspace(lon_min, lon_max, cols)
    lat_vals = np.linspace(lat_min, lat_max, rows)
    lon_grid, lat_grid = np.meshgrid(lon_vals, lat_vals)
    return lon_grid, lat_grid

