"""
ML Pipeline Script for Arizona Groundwater Pumping Prediction.

This script executes the remaining pipeline:
1. Creates dummy annual predictor data from 1896-2099 for AZ and assigns each
   pixel an ADWR groundwater sub-basin label (``GW_Subbasin``).
2. Evaluates tree-based ML models (1984-2024) on three splitting strategies:
   a) Random 80/20 train/test split.
   b) Leave-one-out temporal holdout over multiple test-year ranges (T1-T6),
      reporting per-holdout and averaged metrics.
   c) Leave-one-out spatial holdout over every AMA/INA sub-basin (ADWR),
      reporting per-sub-basin and averaged metrics.
   All strategies use kFolds + Optuna (TPE) + Dask parallelisation.
3. Uses the best model (XGBoost) to predict annual pumping rasters from
   1896-2099 with maps and time series highlighting four eras:
       Hindcast (1896-1983), Historical (1984-2024), Forecast (2025),
       Projected (2026-2099).
"""

# Author: Dr. Sayantan Majumdar
# Email: sayantan.majumdar@dri.edu

import argparse
import logging
import os

import geopandas as gpd
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score

import hydrolibs.dataops as dataops
import hydrolibs.gwops as gwops
import hydrolibs.intercompops as intercompops
import hydrolibs.mlops as mlops
import hydrolibs.partitionops as partops
import hydrolibs.streamflowops as streamflowops
import hydrolibs.uncertaintyops as uncops
import hydrolibs.visualops as vizops
import hydrolibs.wellops as wellops
from hydrolibs.rasterops import read_raster_as_arr, write_raster
from hydrolibs.sysops import makedirs

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================
INPUT_DIR = '../Data/Inputs/'
OUTPUT_DIR = '../Data/Outputs/'

WATER_USE = 'All'
WNAME = 'All_Wells' if WATER_USE == 'All' else 'Irr_Wells'
VECTOR_DIR = os.path.join(INPUT_DIR, 'GW_Data')
MOSAIC_RASTER_RES = 2000
GEE_MOSAIC_DIR = os.path.join(OUTPUT_DIR, f'GEE_Mosaics_{int(MOSAIC_RASTER_RES)}m')
GW_DEPTH_RASTER_DIR = os.path.join(OUTPUT_DIR, f'GW/Rasters/GW_Depths_{WNAME}_{int(MOSAIC_RASTER_RES)}m')
PRED_DATA_DIR = os.path.join(OUTPUT_DIR, f'Predictor_Data_{WNAME}_{int(MOSAIC_RASTER_RES)}m')
MODEL_DIR = os.path.join(OUTPUT_DIR, f'ML_Model_{WNAME}_{int(MOSAIC_RASTER_RES)}m')
GW_CROPPED_RASTER_DIR = os.path.join(GW_DEPTH_RASTER_DIR, 'Cropped')

AZ_GW_BASIN = os.path.join(OUTPUT_DIR, 'GW_Data', 'Vector_Reproj', 'Groundwater_Basin.shp')
ADWR_SUBBASIN_SHP = os.path.join(OUTPUT_DIR, 'GW_Data', 'Vector_Reproj', 'ADWR_Groundwater_Subbasin.shp')

GCLOUD_PROJECT = 'azhydro'
GCLOUD_BUCKET = 'azhydro'
TILE_SIZE = 10000 if MOSAIC_RASTER_RES == 30 else 80000
FILL_ATTR = 'AF Pumped'
MAX_GW = 3000 if WATER_USE == 'All' else None  # 3000 mm (~10 ft)

# AMA_CODE → parent AMA/INA name mapping
AMA_CODE_MAP = {
    'A': 'JOSEPH CITY INA',
    'B': 'PRESCOTT AMA',
    'C': 'PHOENIX AMA',
    'D': 'PINAL AMA',
    'E': 'TUCSON AMA',
    'F': 'DOUGLAS AMA',
    'G': 'HARQUAHALA INA',
    'H': 'SANTA CRUZ AMA',
}

START_YEAR = 1896
END_YEAR = 2099
YEAR_LIST = list(range(1984, 2025))
RANDOM_STATE = 42
N_TRIALS = 100
FOLD_COUNT = 5
N_DASK_WORKERS = 10
USE_OPTUNA = True
USE_DASK = True
INCLUDE_ALL_MODELS = False

USE_AMA_INA = True
DROP_GW_BASINS = ('WILLCOX AMA', 'HUALAPAI VALLEY INA')

DROP_ATTRS = (
    'Year',
    'GW_Basin',
    'GW_Subbasin',
    'easting_m',
    'SW',
    'GW_Basin_Type',
    'annual_peff_pcml_mm',
)

# Temporal holdout configurations (from azhydro.py)
TEMPORAL_HOLDOUTS = {
    'T1': ((2015, 2024),),
    'T2': ((1990, 1992), (2005, 2007), (2022, 2024)),
    'T3': ((2007, 2010),),
    'T4': ((1985, 1989), (2020, 2024)),
    'T5': ((2024, 2024),),
    'T6': ((2010, 2020),),
}


# =============================================================================
# Step 0 — Data preparation (GEE download, GW processing, rasterisation)
# =============================================================================

def prepare_data(skip_download: bool = True, load_files: bool = True) -> list[str]:
    """
    Download GEE data, preprocess GW CSVs, reproject vectors, and create
    all intermediate rasters needed by the ML pipeline.

    Parameters
    ----------
    skip_download : bool
        If *True*, skip the GEE download (use existing tiles).
    load_files : bool
        If *True*, skip recreating files that already exist on disk.

    Returns
    -------
    list[str]
        GEE data band names (needed by ``create_az_data``).
    """
    logger.info('='*60)
    logger.info('Step 0: Data preparation')
    logger.info('='*60)

    az_state_raw = os.path.join(VECTOR_DIR, 'AZ.geojson')
    well_reg_file = os.path.join(VECTOR_DIR, 'Well_Registry_2024', 'Well_Registry.shp')
    gw_csv_dir = os.path.join(VECTOR_DIR, 'Meter Data')
    grain_parquet = os.path.join(VECTOR_DIR, 'GRAIN_v.1.0', 'GeoParquet', 'us-west_GRAIN_v.1.0.parquet')
    output_gw_vector_dir = os.path.join(OUTPUT_DIR, f'GW/Vectors/{WNAME}')
    vector_reproj_dir = os.path.join(OUTPUT_DIR, 'GW_Data/Vector_Reproj')
    output_gw_volume_dir = (
        os.path.join(OUTPUT_DIR, f'GW/Rasters/GW_Volumes_{WNAME}_{int(MOSAIC_RASTER_RES)}m')
    )

    # GEE download & mosaic
    gee_data_dir, data_band_names = dataops.download_gee_data(
        az_state_raw,
        GCLOUD_PROJECT,
        GCLOUD_BUCKET,
        INPUT_DIR,
        START_YEAR,
        END_YEAR,
        skip_download,
        TILE_SIZE,
        num_workers=40,
        worker_memory='1G',
        gee_scale=MOSAIC_RASTER_RES,
        verbose=False,
    )
    dataops.mosaic_tiles(
        gee_data_dir,
        GEE_MOSAIC_DIR,
        START_YEAR,
        END_YEAR,
        already_mosaicked=load_files,
    )

    # GW CSV → per-year shapefiles
    ref_gw_file = gwops.preprocess_gw_csv(
        well_reg_file,
        gw_csv_dir,
        output_gw_vector_dir,
        fill_attr=FILL_ATTR,
        use_only_ama_ina=False,
        already_preprocessed=load_files,
        water_use=WATER_USE,
    )

    # Reproject vectors
    az_vector_reproj = gwops.reproject_vectors(
        VECTOR_DIR,
        vector_reproj_dir,
        ref_file=ref_gw_file,
        already_reprojected=load_files,
    )
    well_reg_file = az_vector_reproj['Well_Registry']
    az_gw_basin = az_vector_reproj['Groundwater_Basin']
    az_sw_watershed = az_vector_reproj['Surface_Watershed']
    cap_service_area = az_vector_reproj['CAP_Service_Area']
    az_state = az_vector_reproj['AZ']

    # GW volume → depth → cropped rasters
    gwops.create_gw_volume_rasters(
        output_gw_vector_dir,
        output_gw_volume_dir,
        value_field=FILL_ATTR,
        xres=MOSAIC_RASTER_RES,
        yres=MOSAIC_RASTER_RES,
        already_created=load_files,
        max_gw=MAX_GW,
    )
    gwops.create_gw_depth_rasters(
        output_gw_volume_dir,
        GW_DEPTH_RASTER_DIR,
        already_created=load_files,
    )
    gwops.crop_gw_rasters(
        GW_DEPTH_RASTER_DIR,
        GW_DEPTH_RASTER_DIR,
        az_state_file=az_state,
        already_cropped=load_files,
    )

    # Canal density & streamflow rasters
    canal_density_file = streamflowops.create_canal_density_raster(
        grain_parquet=grain_parquet,
        az_boundary_file=az_state,
        output_dir=GEE_MOSAIC_DIR,
        xres=MOSAIC_RASTER_RES,
        yres=MOSAIC_RASTER_RES,
        start_year=START_YEAR,
        end_year=END_YEAR,
        already_created=load_files,
    )
    streamflowops.create_streamflow_rasters(
        watershed_geojson=az_sw_watershed,
        cap_service_area_geojson=cap_service_area,
        sites_csv=os.path.join(VECTOR_DIR, 'Streamflow', 'sites.csv'),
        output_dir=GEE_MOSAIC_DIR,
        xres=MOSAIC_RASTER_RES,
        yres=MOSAIC_RASTER_RES,
        start_year=START_YEAR,
        end_year=END_YEAR,
        canal_density_file=canal_density_file,
        already_created=load_files,
    )

    # GW basin, sub-basin & well density rasters
    adwr_subbasin_shp = f'{vector_reproj_dir}ADWR_Groundwater_Subbasin.shp'
    gwops.create_gw_basin_rasters(
        az_gw_basin,
        GEE_MOSAIC_DIR,
        xres=MOSAIC_RASTER_RES,
        yres=MOSAIC_RASTER_RES,
        start_year=START_YEAR,
        end_year=END_YEAR,
        already_created=load_files,
        subbasin_vector=adwr_subbasin_shp,
    )
    gwops.create_well_density_raster(
        well_reg_file,
        GEE_MOSAIC_DIR,
        xres=MOSAIC_RASTER_RES,
        yres=MOSAIC_RASTER_RES,
        start_year=START_YEAR,
        end_year=END_YEAR,
        already_created=load_files,
    )

    # Reproject GEE mosaics to match GW raster grid
    dataops.reproject_gee_mosaics(
        GEE_MOSAIC_DIR,
        PRED_DATA_DIR,
        GW_CROPPED_RASTER_DIR,
        already_reprojected=load_files,
    )

    logger.info('Step 0 complete.')
    return data_band_names


# =============================================================================
# Step 1 — Create AZ predictor data (1896-2099)
# =============================================================================


def create_az_data(data_band_names: list[str]) -> pd.DataFrame:
    """
    Build the AZ predictor dataframe for years START_YEAR to END_YEAR.

    Calls ``dataops.create_az_data_parquet`` which reads each year's
    Predictor, GW_Basin, GW_Subbasin, Streamflow,
    Canal_Weighted_Streamflow, Canal_Density, and Well_Density rasters,
    then maps ADWR sub-basin OBJECTIDs to names and runs EDA.
    """
    logger.info('='*60)
    logger.info('Step 1: Creating AZ predictor data (1896-2099)...')
    logger.info('='*60)

    az_df = dataops.create_az_data_parquet(
        PRED_DATA_DIR,
        GW_CROPPED_RASTER_DIR,
        MODEL_DIR,
        data_band_names,
        AZ_GW_BASIN,
        start_year=START_YEAR,
        end_year=END_YEAR,
        load_parquet=True,
        subbasin_vector=ADWR_SUBBASIN_SHP,
    )
    logger.info(f'AZ data shape: {az_df.shape}')
    logger.info(f'Year range: {az_df.Year.min()} – {az_df.Year.max()}')
    logger.info(f'Columns: {list(az_df.columns)}')

    # EDA
    vizops.explore_az_data(az_df, os.path.join(MODEL_DIR, 'EDA'))
    return az_df


# =============================================================================
# Step 2 — Evaluate tree-based ML models
# =============================================================================

def _compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Compute standard regression metrics."""
    return {
        'R2': r2_score(y_true, y_pred),
        'RMSE_pct': mlops.normalized_rmse(y_true, y_pred),
        'MAE_pct': mlops.normalized_mae(y_true, y_pred),
        'MBE_pct': mlops.normalized_mbe(y_true, y_pred),
    }


def _train_and_evaluate(
        x_train: pd.DataFrame, y_train: np.ndarray,
        x_test: pd.DataFrame, y_test: np.ndarray,
        model_name: str, output_dir: str,
) -> dict:
    """Train a single model with Optuna+Dask and return train/test metrics."""
    model, cv_df = mlops.build_ml_model_optuna_dask(
        x_train, y_train, output_dir, model_name,
        random_state=RANDOM_STATE,
        n_trials=N_TRIALS,
        n_dask_workers=N_DASK_WORKERS,
        use_dask=USE_DASK,
    )
    y_pred_train = np.abs(model.predict(x_train))
    y_pred_test = np.abs(model.predict(x_test))
    train_metrics = _compute_metrics(y_train, y_pred_train)
    test_metrics = _compute_metrics(y_test, y_pred_test)
    return {
        'model': model,
        'cv_df': cv_df,
        'train': train_metrics,
        'test': test_metrics,
    }


# ---- 2a. Random 80/20 evaluation ------------------------------------------
def evaluate_random(az_df: pd.DataFrame) -> dict:
    """Random 80/20 split — single run with compare_all_models."""
    logger.info('='*60)
    logger.info('Step 2a: Random 80/20 evaluation')
    logger.info('='*60)

    ml_models = mlops.get_model_param_dict(
        get_model_names_only=True,
        include_all_models=INCLUDE_ALL_MODELS,
    )
    strategy_dir = os.path.join(MODEL_DIR, 'Model_Evaluation/Random')
    test_year_limits = ((min(YEAR_LIST), max(YEAR_LIST)),)

    data_dir = f'{strategy_dir}data/'
    ret_vals = dataops.create_train_test_data(
        az_df, data_dir,
        drop_attr=DROP_ATTRS,
        random_state=RANDOM_STATE,
        scaling=False, already_created=False,
        year_list=YEAR_LIST, split_strategy=4,
        test_year=True, outlier_op=None,
        test_gw_basins=(),
        use_ama_ina=USE_AMA_INA,
        drop_gw_basins=DROP_GW_BASINS,
        water_use=WATER_USE,
    )
    (x_train, x_test, y_train, y_test,
     x_scaler, y_scaler,
     year_train, year_test,
     basin_train, basin_test) = ret_vals

    comparison_dir = f'{strategy_dir}Model_Comparison/'
    comparison_df = mlops.compare_all_models(
        x_train, x_test, y_train, y_test,
        comparison_dir,
        model_names=ml_models,
        random_state=RANDOM_STATE,
        use_optuna=USE_OPTUNA,
        n_trials=N_TRIALS,
        n_dask_workers=N_DASK_WORKERS,
        use_dask=USE_DASK,
        year_train=year_train,
        year_test=year_test,
        basin_train=basin_train,
        basin_test=basin_test,
        x_scaler=x_scaler,
        y_scaler=y_scaler,
        use_ama_ina=USE_AMA_INA,
        apply_bias_correction=2,
    )
    logger.info(f'\nRandom model comparison:\n{comparison_df.to_string(index=False)}')

    # Per-model visualisations
    for model_name in ml_models:
        bc_pq = f'{comparison_dir}{model_name}/Predictions_{model_name}_BC.parquet'
        raw_pq = f'{comparison_dir}{model_name}/Predictions_{model_name}.parquet'
        pq = bc_pq if os.path.exists(bc_pq) else raw_pq
        if os.path.exists(pq):
            pred_df = pd.read_parquet(pq)
            mlops.generate_model_visualizations(
                pred_df=pred_df,
                output_dir=f'{comparison_dir}{model_name}/Visualizations/',
                model_name=model_name,
                test_case='Random',
                test_year_limits=test_year_limits,
                raster_res=MOSAIC_RASTER_RES,
                use_ama_ina=USE_AMA_INA,
                create_basin_plots=True,
            )

    return {'comparison_df': comparison_df, 'strategy': 'Random'}


# ---- 2b. Leave-one-out temporal holdout ------------------------------------
def evaluate_temporal_loo(az_df: pd.DataFrame) -> dict:
    """
    Evaluate each model on every temporal holdout (T1-T6).

    Returns per-holdout and averaged metrics across all holdouts.
    """
    logger.info('='*60)
    logger.info('Step 2b: LOO Temporal evaluation (T1-T6)')
    logger.info('='*60)

    ml_models = mlops.get_model_param_dict(
        get_model_names_only=True,
        include_all_models=INCLUDE_ALL_MODELS,
    )
    temporal_dir = os.path.join(MODEL_DIR, 'Model_Evaluation/Temporal_LOO')
    makedirs(temporal_dir)

    per_holdout_rows = []  # per-holdout per-model metrics

    for holdout_name, test_year_limits in TEMPORAL_HOLDOUTS.items():
        logger.info(f'\n--- Temporal holdout {holdout_name}: {test_year_limits} ---')
        test_years = []
        for s, e in test_year_limits:
            test_years.extend(range(s, e + 1))
        test_years = tuple(test_years)

        holdout_dir = f'{temporal_dir}{holdout_name}/'
        data_dir = f'{holdout_dir}data/'
        ret_vals = dataops.create_train_test_data(
            az_df, data_dir,
            drop_attr=DROP_ATTRS,
            random_state=RANDOM_STATE,
            scaling=False, already_created=False,
            year_list=YEAR_LIST, split_strategy=1,
            test_year=test_years, outlier_op=None,
            test_gw_basins=(),
            use_ama_ina=USE_AMA_INA,
            drop_gw_basins=DROP_GW_BASINS,
            water_use=WATER_USE,
        )
        (x_train, x_test, y_train, y_test,
         x_scaler, y_scaler,
         year_train, year_test,
         basin_train, basin_test) = ret_vals

        if len(y_test) == 0:
            logger.warning(f'No test data for {holdout_name}, skipping.')
            continue

        for model_name in ml_models:
            logger.info(f'  Training {model_name} for {holdout_name}...')
            model_dir = f'{holdout_dir}{model_name}/'
            res = _train_and_evaluate(
                x_train, y_train, x_test, y_test,
                model_name, model_dir,
            )

            # Prediction results + visualisation
            pred_df = mlops.get_prediction_results(
                res['model'], x_train, x_test,
                y_train, y_test, x_scaler, y_scaler,
                year_train, year_test,
                basin_train, basin_test,
                model_dir, model_name,
                apply_bias_correction=2,
            )
            mlops.calc_train_test_metrics(
                pred_df, res['cv_df'], model_dir,
                use_ama_ina=USE_AMA_INA, model_name=model_name,
            )
            mlops.generate_model_visualizations(
                pred_df=pred_df,
                output_dir=os.path.join(model_dir, 'Visualizations'),
                model_name=model_name,
                test_case=holdout_name,
                test_year_limits=test_year_limits,
                raster_res=MOSAIC_RASTER_RES,
                use_ama_ina=USE_AMA_INA,
                create_basin_plots=False,
            )

            per_holdout_rows.append({
                'Holdout': holdout_name,
                'Model': model_name,
                'Train_R2': res['train']['R2'],
                'Test_R2': res['test']['R2'],
                'Train_RMSE': res['train']['RMSE_pct'],
                'Test_RMSE': res['test']['RMSE_pct'],
                'Test_MAE': res['test']['MAE_pct'],
                'Test_MBE': res['test']['MBE_pct'],
                'Overfit_R2': res['train']['R2'] - res['test']['R2'],
            })

    # Build results DataFrames
    per_holdout_df = pd.DataFrame(per_holdout_rows).round(4)
    per_holdout_df.to_csv(f'{temporal_dir}Per_Holdout_Metrics.csv', index=False)
    logger.info(f'\nPer-holdout metrics:\n{per_holdout_df.to_string(index=False)}')

    # Averaged metrics per model across holdouts
    avg_df = (
        per_holdout_df
        .groupby('Model')
        .agg(
            Mean_Test_R2=('Test_R2', 'mean'),
            Std_Test_R2=('Test_R2', 'std'),
            Mean_Test_RMSE=('Test_RMSE', 'mean'),
            Std_Test_RMSE=('Test_RMSE', 'std'),
            Mean_Test_MAE=('Test_MAE', 'mean'),
            Mean_Test_MBE=('Test_MBE', 'mean'),
            Mean_Overfit_R2=('Overfit_R2', 'mean'),
        )
        .reset_index()
        .sort_values('Mean_Test_RMSE')
        .round(4)
    )
    avg_df.to_csv(f'{temporal_dir}Averaged_Metrics.csv', index=False)
    logger.info(f'\nAveraged temporal metrics:\n{avg_df.to_string(index=False)}')

    # Visualisation: heatmap of Test R² per holdout × model
    vizops.plot_loo_heatmap(
        per_holdout_df, 'Holdout', temporal_dir,
        title='Temporal LOO: Test R² per Holdout',
    )
    vizops.plot_loo_bar(per_holdout_df, 'Holdout', temporal_dir)

    return {
        'per_holdout_df': per_holdout_df,
        'avg_df': avg_df,
        'strategy': 'Temporal_LOO',
    }


# ---- 2c. Leave-one-out spatial holdout (ADWR sub-basins) -------------------
def _get_all_subbasins() -> list[str]:
    """Return all ADWR sub-basin names (excluding dropped basins)."""
    sub_gdf = gpd.read_file(ADWR_SUBBASIN_SHP)
    parent_drop = set()
    for code, name in AMA_CODE_MAP.items():
        if name in DROP_GW_BASINS:
            parent_drop.add(code)
    if parent_drop:
        sub_gdf = sub_gdf[~sub_gdf['AMA_CODE'].isin(parent_drop)]
    return sorted(sub_gdf['SUBBASIN_N'].dropna().unique().tolist())


def _get_ama_ina_subbasins() -> list[str]:
    """Return the list of ADWR sub-basin names within AMA/INA."""
    sub_gdf = gpd.read_file(ADWR_SUBBASIN_SHP)
    ama_ina_codes = set(AMA_CODE_MAP.keys())
    sub_gdf = sub_gdf[sub_gdf['AMA_CODE'].isin(ama_ina_codes)]
    subbasins = sorted(sub_gdf['SUBBASIN_N'].dropna().unique().tolist())
    # Remove any sub-basins whose parent AMA/INA is dropped
    parent_drop = set()
    for code, name in AMA_CODE_MAP.items():
        if name in DROP_GW_BASINS:
            parent_drop.add(code)
    if parent_drop:
        sub_gdf_filt = sub_gdf[~sub_gdf['AMA_CODE'].isin(parent_drop)]
        subbasins = sorted(sub_gdf_filt['SUBBASIN_N'].dropna().unique().tolist())
    return subbasins


def evaluate_spatial_loo(az_df: pd.DataFrame) -> dict:
    """
    Leave-one-out spatial evaluation: hold out each ADWR sub-basin
    within AMA/INA one at a time, train on the rest, evaluate on
    the held-out sub-basin.

    Reports per-sub-basin and averaged metrics.
    """
    logger.info('='*60)
    logger.info('Step 2c: LOO Spatial evaluation (ADWR sub-basins)')
    logger.info('='*60)

    ml_models = mlops.get_model_param_dict(
        get_model_names_only=True,
        include_all_models=INCLUDE_ALL_MODELS,
    )
    subbasins = _get_ama_ina_subbasins()

    # Keep only sub-basins that have data in the metered years
    metered_df = az_df[az_df['Year'].isin(YEAR_LIST)]
    subbasins_with_data = set(metered_df['GW_Subbasin'].unique())
    skipped = [s for s in subbasins if s not in subbasins_with_data]
    subbasins = [s for s in subbasins if s in subbasins_with_data]
    if skipped:
        logger.warning(f'Skipping sub-basins with no data: {skipped}')
    logger.info(f'Sub-basins to evaluate ({len(subbasins)}): {subbasins}')

    spatial_dir = os.path.join(MODEL_DIR, 'Model_Evaluation/Spatial_LOO')
    makedirs(spatial_dir)

    per_subbasin_rows = []

    for subbasin in subbasins:
        logger.info(f'\n--- Spatial holdout: {subbasin} ---')
        subbasin_safe = subbasin.replace(' ', '_').replace('.', '')
        holdout_dir = f'{spatial_dir}{subbasin_safe}/'

        data_dir = f'{holdout_dir}data/'
        ret_vals = dataops.create_train_test_data(
            az_df, data_dir,
            drop_attr=DROP_ATTRS,
            random_state=RANDOM_STATE,
            scaling=False, already_created=False,
            year_list=YEAR_LIST, split_strategy=3,
            test_year=(), outlier_op=None,
            test_gw_basins=(subbasin,),
            gw_basin_col='GW_Subbasin',
            use_ama_ina=False,  # filtering is handled by subbasin list
            drop_gw_basins=(),
            water_use=WATER_USE,
        )
        (x_train, x_test, y_train, y_test,
         x_scaler, y_scaler,
         year_train, year_test,
         basin_train, basin_test) = ret_vals

        if len(y_test) == 0:
            logger.warning(f'No test data for sub-basin {subbasin}, skipping.')
            continue

        logger.info(f'  Train: {len(y_train)}, Test: {len(y_test)}')

        for model_name in ml_models:
            logger.info(f'  Training {model_name} (holdout: {subbasin})...')
            model_dir = f'{holdout_dir}{model_name}/'
            res = _train_and_evaluate(
                x_train, y_train, x_test, y_test,
                model_name, model_dir,
            )

            # Prediction results
            pred_df = mlops.get_prediction_results(
                res['model'], x_train, x_test,
                y_train, y_test, x_scaler, y_scaler,
                year_train, year_test,
                basin_train, basin_test,
                model_dir, model_name,
                gw_basin_col='GW_Subbasin',
                apply_bias_correction=1,  # global bias correction for spatial
            )
            mlops.calc_train_test_metrics(
                pred_df, res['cv_df'], model_dir,
                use_ama_ina=False,
                gw_basin_col='GW_Subbasin',
                model_name=model_name,
            )

            per_subbasin_rows.append({
                'Subbasin': subbasin,
                'Model': model_name,
                'N_test': len(y_test),
                'Train_R2': res['train']['R2'],
                'Test_R2': res['test']['R2'],
                'Train_RMSE': res['train']['RMSE_pct'],
                'Test_RMSE': res['test']['RMSE_pct'],
                'Test_MAE': res['test']['MAE_pct'],
                'Test_MBE': res['test']['MBE_pct'],
                'Overfit_R2': res['train']['R2'] - res['test']['R2'],
            })

    # Build results DataFrames
    per_subbasin_df = pd.DataFrame(per_subbasin_rows).round(4)
    per_subbasin_df.to_csv(f'{spatial_dir}Per_Subbasin_Metrics.csv', index=False)
    logger.info(f'\nPer-sub-basin metrics:\n{per_subbasin_df.to_string(index=False)}')

    # Averaged metrics per model across sub-basins
    avg_df = (
        per_subbasin_df
        .groupby('Model')
        .agg(
            Mean_Test_R2=('Test_R2', 'mean'),
            Std_Test_R2=('Test_R2', 'std'),
            Mean_Test_RMSE=('Test_RMSE', 'mean'),
            Std_Test_RMSE=('Test_RMSE', 'std'),
            Mean_Test_MAE=('Test_MAE', 'mean'),
            Mean_Test_MBE=('Test_MBE', 'mean'),
            Mean_Overfit_R2=('Overfit_R2', 'mean'),
        )
        .reset_index()
        .sort_values('Mean_Test_RMSE')
        .round(4)
    )
    avg_df.to_csv(f'{spatial_dir}Averaged_Metrics.csv', index=False)
    logger.info(f'\nAveraged spatial metrics:\n{avg_df.to_string(index=False)}')

    # Visualisations
    vizops.plot_loo_heatmap(
        per_subbasin_df, 'Subbasin', spatial_dir,
        title='Spatial LOO: Test R² per Sub-basin',
    )
    vizops.plot_loo_bar(per_subbasin_df, 'Subbasin', spatial_dir)

    return {
        'per_subbasin_df': per_subbasin_df,
        'avg_df': avg_df,
        'strategy': 'Spatial_LOO',
    }


# =============================================================================
# Step 3 — Predict annual pumping rasters 1896-2099 with XGBoost
# =============================================================================
def _valid_pixels_to_raster(
        values: np.ndarray,
        valid_mask: np.ndarray,
        raster_shape: tuple,
) -> np.ndarray:
    """Map valid-pixel values back to a full 2-D raster grid."""
    grid = np.full(valid_mask.shape[0], np.nan, dtype=np.float32)
    grid[valid_mask] = values.astype(np.float32)
    return grid.reshape(raster_shape)


def _write_multi_unit_rasters(
        mm_grid: np.ndarray,
        out_dirs: dict[str, str],
        prefix: str,
        year: int,
        ref_raster_file: str,
        mm_to_ft: float,
        mm_to_m3: float,
        m3_to_af: float,
) -> None:
    """Write a depth grid in mm, ft, m³, and AF."""
    unit_grids = {
        'mm': mm_grid,
        'ft': mm_grid * mm_to_ft,
        'm3': mm_grid * mm_to_m3,
        'AF': mm_grid * mm_to_m3 * m3_to_af,
    }
    for unit, grid in unit_grids.items():
        _, raster_file_obj = read_raster_as_arr(ref_raster_file, get_file=True)
        out_path = f'{out_dirs[unit]}{prefix}_{year}_{unit}.tif'
        write_raster(
            grid, raster_file_obj,
            raster_file_obj.transform, out_path,
            no_data_value=np.nan,
        )
        raster_file_obj.close()


def predict_full_period(az_df: pd.DataFrame) -> tuple:
    """
    Train XGBoost on the full 1984-2024 metered data (temporal split T1)
    and predict groundwater pumping rasters for every year from 1896 to 2099.

    Returns
    -------
    tuple
        (model, feature_cols, x_train, y_train) — the trained XGBoost model,
        feature column names, and training data for uncertainty quantification.
    """
    logger.info('='*60)
    logger.info('Step 3: XGBoost full-period prediction (1896-2099)')
    logger.info('='*60)

    model_name = 'XGB'
    prediction_dir = os.path.join(MODEL_DIR, f'Full_Prediction_{model_name}')
    makedirs(prediction_dir)

    # ---- 3a. Train on ALL 1984-2024 metered data (no holdout) ----
    # Step 2 already provides thorough LOO evaluation; here we maximise
    # training data for the best possible full-period predictions.
    data_dir = os.path.join(prediction_dir, 'data')
    ret_vals = dataops.create_train_test_data(
        az_df, data_dir,
        drop_attr=DROP_ATTRS,
        random_state=RANDOM_STATE,
        scaling=False,
        already_created=False,
        year_list=YEAR_LIST,
        split_strategy=1,
        test_year=(),
        outlier_op=None,
        test_gw_basins=(),
        use_ama_ina=USE_AMA_INA,
        drop_gw_basins=DROP_GW_BASINS,
        water_use=WATER_USE,
    )
    x_train, y_train = ret_vals[0], ret_vals[2]

    logger.info(f'Training XGBoost on {len(x_train)} samples '
                f'({YEAR_LIST[0]}-{YEAR_LIST[-1]}, all years)...')
    model, _ = mlops.build_ml_model_optuna_dask(
        x_train, y_train,
        os.path.join(prediction_dir, 'Model'),
        model_name, RANDOM_STATE,
        n_trials=N_TRIALS,
        n_dask_workers=N_DASK_WORKERS,
        use_dask=USE_DASK,
    )

    # ---- Model interpretability plots ----
    interp_dir = os.path.join(prediction_dir, 'Model_Interpretability')

    # Feature importance + permutation importance
    mlops.compute_perm_imp(
        model_name, x_train, x_train, y_train, y_train,
        model, interp_dir, scoring_metric='scaled_rmse',
        random_state=RANDOM_STATE, create_plots=True,
    )

    # ALE plots
    mlops.compute_ale_plots(
        model_name, model,
        x_train, y_train, x_train, y_train,
        interp_dir,
    )

    # SHAP plots
    mlops.compute_shap_plots(
        model_name, model, x_train, interp_dir,
    )

    # ---- 3b. Predict pumping for each year 1896-2099 ----
    logger.info('Predicting pumping for all years 1896-2099...')

    feature_cols = list(x_train.columns)
    raster_dir = os.path.join(prediction_dir, 'Predicted_Rasters')
    raster_dirs = {
        'mm': os.path.join(raster_dir, 'Depth_mm'),
        'ft': os.path.join(raster_dir, 'Depth_ft'),
        'm3': os.path.join(raster_dir, 'Volume_m3'),
        'AF': os.path.join(raster_dir, 'Volume_AF'),
    }
    for d in raster_dirs.values():
        makedirs(d)

    # Category-specific raster directories
    cat_raster_dirs = {}
    for cat in partops.CATEGORIES:
        base = os.path.join(prediction_dir, f'{cat}_Rasters')
        cat_raster_dirs[cat] = {
            'mm': f'{base}Depth_mm/',
            'ft': f'{base}Depth_ft/',
            'm3': f'{base}Volume_m3/',
            'AF': f'{base}Volume_AF/',
        }
        for d in cat_raster_dirs[cat].values():
            makedirs(d)

    # Consumptive use raster directories
    CU_CATEGORIES = ('Irrigation_CU', 'Irrigation_GW_CU', 'Irrigation_SW_CU')
    cu_raster_dirs = {}
    for cu_cat in CU_CATEGORIES:
        base = os.path.join(prediction_dir, f'{cu_cat}_Rasters')
        cu_raster_dirs[cu_cat] = {
            'mm': f'{base}Depth_mm/',
            'ft': f'{base}Depth_ft/',
            'm3': f'{base}Volume_m3/',
            'AF': f'{base}Volume_AF/',
        }
        for d in cu_raster_dirs[cu_cat].values():
            makedirs(d)

    # Irrigation efficiency raster directories (dimensionless ratios)
    IE_CATEGORIES = ('Irrigation_Efficiency', 'Irrigation_GW_Efficiency', 'Irrigation_SW_Efficiency')
    ie_raster_dirs = {}
    for ie_cat in IE_CATEGORIES:
        ie_raster_dirs[ie_cat] = os.path.join(prediction_dir, f'{ie_cat}_Rasters')
        makedirs(ie_raster_dirs[ie_cat])

    # Build a valid-pixel mask from the GW_Basin raster (same for all years).
    # In create_az_data_parquet, pixels with NaN or 0 in GW_Basin are labelled
    # 'OUTSIDE AZ' and dropped.  The remaining rows — in ravel order — are
    # what appears in az_df for each year.
    ref_basin_file = f'{PRED_DATA_DIR}GW_Basin_{YEAR_LIST[0]}.tif'
    basin_arr, basin_file_obj = read_raster_as_arr(ref_basin_file, get_file=True)
    basin_flat = basin_arr.ravel()
    valid_mask = ~np.isnan(basin_flat) & (basin_flat != 0)
    raster_shape = basin_arr.shape
    basin_file_obj.close()

    # Reference raster for spatial metadata (CRS, transform)
    ref_raster_file = f'{PRED_DATA_DIR}Predictor_{YEAR_LIST[0]}.tif'

    # All AZ basin names (for per-basin summary statistics)
    all_basins = sorted(az_df['GW_Basin'].unique().tolist())
    all_basins = [b for b in all_basins if b not in DROP_GW_BASINS]

    # All sub-basins (for summary statistics)
    subbasins = _get_all_subbasins()

    pixel_area_m2 = MOSAIC_RASTER_RES ** 2
    mm_to_m3 = pixel_area_m2 / 1000          # depth mm × pixel → volume m³
    m3_to_af = 1 / 1233.48                   # m³ → acre-ft
    mm_to_ft = 1 / 304.8                     # mm → ft

    def _pixel_stats(pred_vals):
        """Compute depth and volume stats in multiple units."""
        n = len(pred_vals)
        mean_mm = float(np.nanmean(pred_vals)) if n > 0 else 0.0
        vol_m3 = float(np.nansum(pred_vals)) * mm_to_m3
        return {
            'Mean_Depth_mm': round(mean_mm, 4),
            'Mean_Depth_ft': round(mean_mm * mm_to_ft, 6),
            'Volume_m3': round(vol_m3, 2),
            'Volume_AF': round(vol_m3 * m3_to_af, 2),
        }

    yearly_predictions = {}        # year → {metrics dict}  (total pumping)
    basin_yearly = {}              # year → {basin_name: metrics dict}
    subbasin_yearly = {}           # year → {subbasin_name: metrics dict}

    # Actual (metered) data for available years
    actual_yearly = {}             # year → {metrics dict}
    actual_basin_yearly = {}       # year → {basin_name: metrics dict}
    actual_subbasin_yearly = {}    # year → {subbasin_name: metrics dict}

    # Per-category tracking dicts: cat → {year → ...}
    cat_yearly = {cat: {} for cat in partops.CATEGORIES}
    cat_basin_yearly = {cat: {} for cat in partops.CATEGORIES}
    cat_subbasin_yearly = {cat: {} for cat in partops.CATEGORIES}

    # Consumptive use tracking dicts
    cu_yearly = {cat: {} for cat in CU_CATEGORIES}
    cu_basin_yearly = {cat: {} for cat in CU_CATEGORIES}
    cu_subbasin_yearly = {cat: {} for cat in CU_CATEGORIES}

    # Irrigation efficiency tracking dicts
    ie_yearly = {cat: {} for cat in IE_CATEGORIES}
    ie_basin_yearly = {cat: {} for cat in IE_CATEGORIES}
    ie_subbasin_yearly = {cat: {} for cat in IE_CATEGORIES}

    for year in range(START_YEAR, END_YEAR + 1):
        year_df = az_df[az_df.Year == year].copy()
        if year_df.empty:
            logger.warning(f'No data for year {year}, skipping.')
            continue

        # XGBoost features = create_az_data_parquet columns - DROP_ATTRS - target
        drop_list = [a for a in DROP_ATTRS if a in year_df.columns]
        pred_features = year_df.drop(
            columns=drop_list + ['gw_pumping_mm'],
            errors='ignore'
        )
        # Ensure same columns and order as training
        for c in feature_cols:
            if c not in pred_features.columns:
                pred_features[c] = 0
        pred_features = pred_features[feature_cols]
        pred_features = pred_features.replace([np.inf, -np.inf], np.nan).fillna(0)

        predictions = np.abs(model.predict(pred_features))

        # Partition into irrigation/non-irrigation and GW/SW categories
        cat_predictions = partops.partition_predictions(
            predictions, year_df, raster_shape, valid_mask,
        )
        predictions = cat_predictions['Irrigation'] + cat_predictions['Non_Irrigation']

        # Reconstruct raster: valid_mask marks the pixels that survived
        # the 'OUTSIDE AZ' filter in create_az_data_parquet.
        pred_mm = _valid_pixels_to_raster(predictions, valid_mask, raster_shape)
        _write_multi_unit_rasters(
            pred_mm, raster_dirs, 'Predicted_GW', year,
            ref_raster_file, mm_to_ft, mm_to_m3, m3_to_af,
        )

        # Write category rasters (irr, non-irr, irr_gw, irr_sw, nonirr_gw, nonirr_sw)
        for cat, cat_pred in cat_predictions.items():
            cat_mm = _valid_pixels_to_raster(cat_pred, valid_mask, raster_shape)
            _write_multi_unit_rasters(
                cat_mm, cat_raster_dirs[cat], cat, year,
                ref_raster_file, mm_to_ft, mm_to_m3, m3_to_af,
            )

        # ---- Consumptive use and irrigation efficiency ----
        et_vals = year_df['annual_et_ensemble_mm'].values.copy()
        peff_vals = year_df['annual_peff_mm'].values.copy()

        # Reuse the same irr_fraction logic as partition_predictions
        irr_frac = year_df['annual_irr_fraction'].values.copy() \
            if 'annual_irr_fraction' in year_df.columns else np.ones(len(et_vals))
        well_dens = year_df['well_density'].values \
            if 'well_density' in year_df.columns else None
        if well_dens is not None and 'annual_irr_fraction' in year_df.columns:
            irr_frac = partops.focal_fill_irr_fraction(
                irr_frac, well_dens, raster_shape, valid_mask,
            )
        gw_frac = year_df['annual_gw_fraction'].values.copy() \
            if 'annual_gw_fraction' in year_df.columns else np.ones(len(et_vals))
        gw_frac = np.clip(np.nan_to_num(gw_frac, nan=1.0), 0, 1)

        # Partition ET and Peff into irrigation / GW / SW
        et_irr = et_vals * irr_frac
        peff_irr = peff_vals * irr_frac

        # Consumptive use = irrigation ET − effective precip (≥ 0)
        cu_total = np.maximum(et_irr - peff_irr, 0)
        cu_gw = cu_total * gw_frac
        cu_sw = cu_total - cu_gw

        cu_dict = {
            'Irrigation_CU': cu_total,
            'Irrigation_GW_CU': cu_gw,
            'Irrigation_SW_CU': cu_sw,
        }

        # Irrigation efficiency = CU / withdrawal
        withdrawal_map = {
            'Irrigation_Efficiency': 'Irrigation',
            'Irrigation_GW_Efficiency': 'Irrigation_GW',
            'Irrigation_SW_Efficiency': 'Irrigation_SW',
        }
        cu_for_ie = {
            'Irrigation_Efficiency': cu_total,
            'Irrigation_GW_Efficiency': cu_gw,
            'Irrigation_SW_Efficiency': cu_sw,
        }
        ie_dict = {}
        for ie_cat, wd_cat in withdrawal_map.items():
            wd_vals = cat_predictions[wd_cat]
            with np.errstate(invalid='ignore', divide='ignore'):
                ie_vals = np.where(wd_vals > 0,
                                   cu_for_ie[ie_cat] / wd_vals, np.nan)
            ie_dict[ie_cat] = ie_vals

        # Write consumptive use rasters (multiple units)
        for cu_cat, cu_pred in cu_dict.items():
            cu_mm = _valid_pixels_to_raster(cu_pred, valid_mask, raster_shape)
            _write_multi_unit_rasters(
                cu_mm, cu_raster_dirs[cu_cat], cu_cat, year,
                ref_raster_file, mm_to_ft, mm_to_m3, m3_to_af,
            )

        # Write irrigation efficiency rasters (dimensionless)
        for ie_cat, ie_vals in ie_dict.items():
            ie_grid = _valid_pixels_to_raster(ie_vals, valid_mask, raster_shape)
            _, raster_file_obj = read_raster_as_arr(ref_raster_file, get_file=True)
            out_path = f'{ie_raster_dirs[ie_cat]}{ie_cat}_{year}.tif'
            write_raster(
                ie_grid, raster_file_obj,
                raster_file_obj.transform, out_path,
                no_data_value=np.nan,
            )
            raster_file_obj.close()

        # AZ-wide annual total (all valid pixels)
        yearly_predictions[year] = _pixel_stats(predictions)
        for cat, cat_pred in cat_predictions.items():
            cat_yearly[cat][year] = _pixel_stats(cat_pred)
        for cu_cat, cu_pred in cu_dict.items():
            cu_yearly[cu_cat][year] = _pixel_stats(cu_pred)
        for ie_cat, ie_vals in ie_dict.items():
            valid_ie = ie_vals[np.isfinite(ie_vals)]
            ie_yearly[ie_cat][year] = {
                'Mean_Efficiency': round(float(np.nanmean(valid_ie)), 4) if len(valid_ie) > 0 else np.nan,
            }

        # Collect actual meter data for metered years
        if year in YEAR_LIST and 'gw_pumping_mm' in year_df.columns:
            actuals = year_df['gw_pumping_mm'].values
            actual_yearly[year] = _pixel_stats(actuals)
            act_basin_totals = {}
            act_subbasin_totals = {}
            for basin in all_basins:
                bmask = (year_df.GW_Basin == basin).values
                act_basin_totals[basin] = _pixel_stats(actuals[bmask])
            actual_basin_yearly[year] = act_basin_totals
            for sb in subbasins:
                sbmask = (year_df.GW_Subbasin == sb).values
                act_subbasin_totals[sb] = _pixel_stats(actuals[sbmask])
            actual_subbasin_yearly[year] = act_subbasin_totals

        # Per-basin annual stats (all AZ basins)
        basin_totals = {}
        cat_basin_totals = {cat: {} for cat in partops.CATEGORIES}
        cu_basin_totals = {cat: {} for cat in CU_CATEGORIES}
        ie_basin_totals = {cat: {} for cat in IE_CATEGORIES}
        for basin in all_basins:
            bmask = (year_df.GW_Basin == basin).values
            basin_totals[basin] = _pixel_stats(predictions[bmask])
            for cat, cat_pred in cat_predictions.items():
                cat_basin_totals[cat][basin] = _pixel_stats(cat_pred[bmask])
            for cu_cat, cu_pred in cu_dict.items():
                cu_basin_totals[cu_cat][basin] = _pixel_stats(cu_pred[bmask])
            for ie_cat, ie_vals in ie_dict.items():
                valid_ie = ie_vals[bmask]
                valid_ie = valid_ie[np.isfinite(valid_ie)]
                ie_basin_totals[ie_cat][basin] = {
                    'Mean_Efficiency': round(float(np.nanmean(valid_ie)), 4) if len(valid_ie) > 0 else np.nan,
                }
        basin_yearly[year] = basin_totals
        for cat in partops.CATEGORIES:
            cat_basin_yearly[cat][year] = cat_basin_totals[cat]
        for cu_cat in CU_CATEGORIES:
            cu_basin_yearly[cu_cat][year] = cu_basin_totals[cu_cat]
        for ie_cat in IE_CATEGORIES:
            ie_basin_yearly[ie_cat][year] = ie_basin_totals[ie_cat]

        # Per-sub-basin annual stats
        subbasin_totals = {}
        cat_subbasin_totals = {cat: {} for cat in partops.CATEGORIES}
        cu_subbasin_totals = {cat: {} for cat in CU_CATEGORIES}
        ie_subbasin_totals = {cat: {} for cat in IE_CATEGORIES}
        for sb in subbasins:
            sbmask = (year_df.GW_Subbasin == sb).values
            subbasin_totals[sb] = _pixel_stats(predictions[sbmask])
            for cat, cat_pred in cat_predictions.items():
                cat_subbasin_totals[cat][sb] = _pixel_stats(cat_pred[sbmask])
            for cu_cat, cu_pred in cu_dict.items():
                cu_subbasin_totals[cu_cat][sb] = _pixel_stats(cu_pred[sbmask])
            for ie_cat, ie_vals in ie_dict.items():
                valid_ie = ie_vals[sbmask]
                valid_ie = valid_ie[np.isfinite(valid_ie)]
                ie_subbasin_totals[ie_cat][sb] = {
                    'Mean_Efficiency': round(float(np.nanmean(valid_ie)), 4) if len(valid_ie) > 0 else np.nan,
                }
        subbasin_yearly[year] = subbasin_totals
        for cat in partops.CATEGORIES:
            cat_subbasin_yearly[cat][year] = cat_subbasin_totals[cat]
        for cu_cat in CU_CATEGORIES:
            cu_subbasin_yearly[cu_cat][year] = cu_subbasin_totals[cu_cat]
        for ie_cat in IE_CATEGORIES:
            ie_subbasin_yearly[ie_cat][year] = ie_subbasin_totals[ie_cat]

        if year % 20 == 0 or year == END_YEAR:
            vol_af = yearly_predictions[year]['Volume_AF']
            irr_gw = cat_yearly['Irrigation_GW'][year]['Volume_AF']
            irr_sw = cat_yearly['Irrigation_SW'][year]['Volume_AF']
            nigw = cat_yearly['Non_Irrigation_GW'][year]['Volume_AF']
            nisw = cat_yearly['Non_Irrigation_SW'][year]['Volume_AF']
            cu_af = cu_yearly['Irrigation_CU'][year]['Volume_AF']
            ie_mean = ie_yearly['Irrigation_Efficiency'][year]['Mean_Efficiency']
            logger.info(
                f'  Year {year}: total = {vol_af:,.0f} AF'
                f'  |  irr_GW = {irr_gw:,.0f}  irr_SW = {irr_sw:,.0f}'
                f'  |  non-irr_GW = {nigw:,.0f}  non-irr_SW = {nisw:,.0f}'
                f'  |  CU = {cu_af:,.0f} AF  IE = {ie_mean:.2f}'
            )

    # ---- 3c. Era summary maps (time series plots deferred to UQ step) ----
    vizops.create_era_summary_maps(yearly_predictions, prediction_dir)

    CAT_TITLES = {
        'Irrigation':         'Irrigation',
        'Non_Irrigation':     'Non-Irrigation',
        'Irrigation_GW':      'Irrigation GW',
        'Irrigation_SW':      'Irrigation SW',
        'Non_Irrigation_GW':  'Non-Irrigation GW',
        'Non_Irrigation_SW':  'Non-Irrigation SW',
        'Total_GW':           'Total GW',
        'Total_SW':           'Total SW',
    }
    for cat, title in CAT_TITLES.items():
        cat_dir = os.path.join(prediction_dir, cat)
        vizops.create_era_summary_maps(
            cat_yearly[cat], cat_dir,
            title_prefix=title,
        )

    CU_TITLES = {
        'Irrigation_CU':    'Irrigation Consumptive Use',
        'Irrigation_GW_CU': 'Irrigation GW Consumptive Use',
        'Irrigation_SW_CU': 'Irrigation SW Consumptive Use',
    }
    for cu_cat, title in CU_TITLES.items():
        cu_dir = os.path.join(prediction_dir, cu_cat)
        vizops.create_era_summary_maps(
            cu_yearly[cu_cat], cu_dir,
            title_prefix=title,
        )

    # ---- 3d. Well package (per-well annual withdrawals as GeoPackage) ----
    well_registry_file = os.path.join(OUTPUT_DIR, 'GW_Data', 'Vector_Reproj', 'Well_Registry.shp')
    gw_vector_dir = os.path.join(OUTPUT_DIR, f'GW/Vectors/{WNAME}')
    wellops.create_well_package(
        well_registry_file,
        raster_dirs=raster_dirs,
        cat_raster_dirs=cat_raster_dirs,
        output_dir=os.path.join(prediction_dir, 'Well_Package'),
        ref_raster_file=ref_raster_file,
        pixel_area_m2=pixel_area_m2,
        start_year=START_YEAR,
        end_year=END_YEAR,
        water_use='All' if WATER_USE == 'All' else 'IRRIGATION',
        gw_vector_dir=gw_vector_dir,
    )

    logger.info(f'Full-period prediction complete. Results in {prediction_dir}')
    return model, feature_cols, x_train, y_train


# =============================================================================
# Step 4 — Intercomparison with USGS datasets
# =============================================================================

def run_usgs_intercomparison() -> pd.DataFrame:
    """
    Compare ML-based irrigation withdrawal predictions with USGS NHM
    (HUC12-scale) and USGS Reitz (county-scale raster) datasets across
    Arizona groundwater basins.

    Returns
    -------
    pd.DataFrame
        Summary metrics for every pairwise comparison × category.
    """
    logger.info('='*60)
    logger.info('Step 4: USGS Intercomparison')
    logger.info('='*60)

    prediction_dir = os.path.join(MODEL_DIR, 'Full_Prediction_XGB')
    ml_pred_dir = os.path.join(prediction_dir, 'Predicted_Rasters/Depth_mm')
    irr_gw_dir = os.path.join(prediction_dir, 'Irrigation_GW_Rasters/Depth_mm')
    irr_sw_dir = os.path.join(prediction_dir, 'Irrigation_SW_Rasters/Depth_mm')

    nhm_dir = os.path.join(INPUT_DIR, 'USGS WU/USGS_NHM_Withdrawals')
    reitz_base_dir = os.path.join(INPUT_DIR, 'USGS WU/USGS_Reitz_Irrigation')
    huc12_geojson = os.path.join(INPUT_DIR, 'GEE_Data', 'AZ_HUC12.geojson')

    output_dir = os.path.join(prediction_dir, 'Intercomparison')

    return intercompops.run_intercomparison(
        ml_pred_dir=ml_pred_dir,
        nhm_dir=nhm_dir,
        reitz_base_dir=reitz_base_dir,
        huc12_geojson=huc12_geojson,
        basin_shp=AZ_GW_BASIN,
        basin_col='BASIN_NAME',
        output_dir=output_dir,
        irr_gw_dir=irr_gw_dir,
        irr_sw_dir=irr_sw_dir,
        predictor_dir=PRED_DATA_DIR,
    )


def run_cu_ie_usgs_intercomparison() -> pd.DataFrame:
    """
    Compare ML-based Irrigation CU and IE predictions with USGS NHM
    HUC12-scale data across Arizona groundwater basins.

    Returns
    -------
    pd.DataFrame
        Summary metrics for CU and IE intercomparisons.
    """
    logger.info('=' * 60)
    logger.info('Step 4b: CU / IE Intercomparison')
    logger.info('=' * 60)

    prediction_dir = os.path.join(MODEL_DIR, 'Full_Prediction_XGB')
    irr_cu_dir = os.path.join(prediction_dir, 'Irrigation_CU_Rasters/Depth_mm')
    irr_ie_dir = os.path.join(prediction_dir, 'Irrigation_Efficiency_Rasters')

    nhm_cu_csv = os.path.join(INPUT_DIR, 'USGS WU', 'USGS_NHM_CUIrr', 'Irr_CU_HUC12_Tot_annual_2000_2020.csv')
    nhm_ie_csv = os.path.join(INPUT_DIR, 'USGS WU', 'USGS_NHM_Withdrawals', 'IR_HUC12_Eff_annual_2000_2020.csv')
    huc12_geojson = os.path.join(INPUT_DIR, 'GEE_Data', 'AZ_HUC12.geojson')

    output_dir = os.path.join(prediction_dir, 'CU_IE_Intercomparison')

    return intercompops.run_cu_ie_intercomparison(
        irr_cu_dir=irr_cu_dir,
        irr_ie_dir=irr_ie_dir,
        nhm_cu_csv=nhm_cu_csv,
        nhm_ie_csv=nhm_ie_csv,
        huc12_geojson=huc12_geojson,
        basin_shp=AZ_GW_BASIN,
        basin_col='BASIN_NAME',
        output_dir=output_dir,
        predictor_dir=PRED_DATA_DIR,
    )


def run_cap_srp_sw_validation() -> pd.DataFrame:
    """
    Validate ML Total_SW predictions against observed CAP and SRP
    surface-water delivery records across Arizona groundwater basins.

    Returns
    -------
    pd.DataFrame
        Per-basin statistics (RMSD, MAD, Pct Diff, Pearson R).
    """
    logger.info('=' * 60)
    logger.info('Step 4c: CAP/SRP Total SW Validation')
    logger.info('=' * 60)

    prediction_dir = os.path.join(MODEL_DIR, 'Full_Prediction_XGB')
    total_sw_dir = os.path.join(prediction_dir, 'Total_SW_Rasters/Depth_mm')

    cap_xlsx = os.path.join(VECTOR_DIR, 'CAP', 'CAP Delivery Data DRI Request.xlsx')
    srp_xlsx = os.path.join(VECTOR_DIR, 'SRP', 'SRP WATER DELVS HISTORY.xlsx')

    output_dir = os.path.join(prediction_dir, 'CAP_SRP_Validation')

    return intercompops.run_cap_srp_validation(
        cap_xlsx=cap_xlsx,
        srp_xlsx=srp_xlsx,
        total_sw_dir=total_sw_dir,
        basin_shp=AZ_GW_BASIN,
        basin_col='BASIN_NAME',
        output_dir=output_dir,
    )


def run_peff_usgs_intercomparison() -> pd.DataFrame:
    """
    Compare irrigated effective precipitation from ML predictions
    (SCS-based and PCML-based) with USGS NHM PPTeff data.

    Returns
    -------
    pd.DataFrame
        Summary metrics for Peff intercomparisons.
    """
    logger.info('=' * 60)
    logger.info('Step 4d: Effective Precipitation Intercomparison')
    logger.info('=' * 60)

    prediction_dir = os.path.join(MODEL_DIR, 'Full_Prediction_XGB')
    nhm_peff_csv = os.path.join(
        INPUT_DIR, 'USGS WU', 'USGS_NHM_CUIrr',
        'PPTeff_HUC12_Tot_annual_2000_2020.csv',
    )
    huc12_geojson = os.path.join(INPUT_DIR, 'GEE_Data', 'AZ_HUC12.geojson')
    output_dir = os.path.join(prediction_dir, 'Peff_Intercomparison')

    return intercompops.run_peff_intercomparison(
        predictor_dir=PRED_DATA_DIR,
        nhm_peff_csv=nhm_peff_csv,
        huc12_geojson=huc12_geojson,
        basin_shp=AZ_GW_BASIN,
        basin_col='BASIN_NAME',
        output_dir=output_dir,
    )


# =============================================================================
# Main
# =============================================================================
STEP_HELP = """\
Pipeline steps (comma-separated or 'all'):
  0    Data preparation (GEE download, GW processing)
  1    Create AZ dataset (Parquet)
  2a   Evaluate random 80/20 split
  2b   Evaluate LOO temporal holdout
  2c   Evaluate LOO spatial holdout
  3    Full-period XGBoost prediction (1896-2099)
  3b   Hybrid uncertainty quantification
  4    USGS intercomparison
  4b   CU / IE intercomparison
  4c   CAP/SRP surface-water validation
  4d   Effective precipitation intercomparison
"""


def main() -> None:
    """
    Run the AZ-Hydro pipeline.

    Supports selective step execution via ``--steps``:

        python pipeline.py --steps 0,1,2a
        python pipeline.py --steps 3   # prediction only
        python pipeline.py              # runs all steps
    """
    parser = argparse.ArgumentParser(
        description='ML Pipeline for Arizona Groundwater Pumping Prediction.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=STEP_HELP,
    )
    parser.add_argument(
        '--steps', type=str, default='all',
        help='Comma-separated step IDs to run (e.g. "0,1,2a") or "all".',
    )
    parser.add_argument(
        '--skip-download', action='store_true', default=True,
        help='Skip GEE tile download (use existing tiles). Default: True.',
    )
    parser.add_argument(
        '--download', dest='skip_download', action='store_false',
        help='Force GEE tile download.',
    )
    parser.add_argument(
        '--load-files', action='store_true', default=True,
        help='Skip recreating intermediate files that already exist. Default: True.',
    )
    parser.add_argument(
        '--recreate', dest='load_files', action='store_false',
        help='Force recreation of intermediate files.',
    )
    args = parser.parse_args()

    run_all = args.steps.lower() == 'all'
    selected = set(s.strip().lower() for s in args.steps.split(',')) if not run_all else set()
    skip_download = args.skip_download
    load_files = args.load_files

    data_band_names = None

    def should_run(step_id: str) -> bool:
        return run_all or step_id in selected

    # Step 0 — Data preparation
    if should_run('0'):
        data_band_names = prepare_data(
            skip_download=skip_download,
            load_files=load_files,
        )

    # Ensure band names are available for downstream steps
    if data_band_names is None:
        _, data_band_names = dataops.download_gee_data(
            os.path.join(VECTOR_DIR, 'AZ.geojson'),
            GCLOUD_PROJECT, GCLOUD_BUCKET,
            INPUT_DIR,
            START_YEAR, END_YEAR,
            skip_download=True,
            tile_size=TILE_SIZE,
        )

    az_df = None

    def get_az_df():
        nonlocal az_df
        if az_df is None:
            az_df = create_az_data(data_band_names)
        return az_df

    # Step 1
    if should_run('1'):
        get_az_df()

    # Step 2a — Random
    random_results = None
    if should_run('2a'):
        random_results = evaluate_random(get_az_df())

    # Step 2b — LOO Temporal
    temporal_results = None
    if should_run('2b'):
        temporal_results = evaluate_temporal_loo(get_az_df())

    # Step 2c — LOO Spatial (ADWR sub-basins)
    spatial_results = None
    if should_run('2c'):
        spatial_results = evaluate_spatial_loo(get_az_df())

    # Cross-strategy summary (only if all 3 evaluations ran)
    if all(r is not None for r in (random_results, temporal_results, spatial_results)):
        vizops.create_cross_strategy_summary(
            {
                'Random': random_results,
                'Temporal_LOO': temporal_results,
                'Spatial_LOO': spatial_results,
            },
            os.path.join(MODEL_DIR, 'Model_Evaluation'),
        )

    # Step 3
    model = feature_cols = x_train = y_train = None
    if should_run('3'):
        model, feature_cols, x_train, y_train = predict_full_period(get_az_df())

    # Step 3b — Hybrid uncertainty quantification
    if should_run('3b'):
        if model is None:
            logger.warning('Step 3b requires a trained model from step 3. Skipping.')
        else:
            uncops.run_uncertainty_quantification(
                model=model,
                feature_cols=feature_cols,
                x_train=x_train,
                y_train=y_train,
                az_df=get_az_df(),
                drop_attrs=DROP_ATTRS,
                pred_data_dir=PRED_DATA_DIR,
                model_dir=MODEL_DIR,
                input_dir=INPUT_DIR,
                output_dir=OUTPUT_DIR,
                vector_dir=VECTOR_DIR,
                mosaic_res=MOSAIC_RASTER_RES,
                gcloud_project=GCLOUD_PROJECT,
                gcloud_bucket=GCLOUD_BUCKET,
                tile_size=TILE_SIZE,
                start_year=START_YEAR,
                end_year=END_YEAR,
                year_list=YEAR_LIST,
                n_trials=N_TRIALS,
                n_dask_workers=N_DASK_WORKERS,
                use_dask=USE_DASK,
                skip_download=skip_download,
                subbasin_shp=ADWR_SUBBASIN_SHP,
                ama_code_map=AMA_CODE_MAP,
                basin_shp=AZ_GW_BASIN,
            )

    # Step 4
    if should_run('4'):
        run_usgs_intercomparison()

    # Step 4b — CU / IE intercomparison
    if should_run('4b'):
        run_cu_ie_usgs_intercomparison()

    # Step 4c — CAP/SRP total surface water validation
    if should_run('4c'):
        run_cap_srp_sw_validation()

    # Step 4d — Effective precipitation intercomparison
    if should_run('4d'):
        run_peff_usgs_intercomparison()

    logger.info('\n' + '='*60)
    logger.info('Pipeline complete!')
    logger.info('='*60)


if __name__ == '__main__':
    main()
